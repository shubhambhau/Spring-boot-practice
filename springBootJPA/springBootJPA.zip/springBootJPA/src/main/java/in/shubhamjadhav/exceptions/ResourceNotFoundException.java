package in.shubhamjadhav.exceptions;

public class ResourceNotFoundException {

}
